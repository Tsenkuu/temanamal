<?php
/*
|--------------------------------------------------------------------------
| File: amil/templates/footer_amil.php
|--------------------------------------------------------------------------
|
| Footer untuk semua halaman di area Amil.
|
*/
?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>