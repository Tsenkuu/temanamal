<?php
/*
|--------------------------------------------------------------------------
| File: amil/templates/header_amil.php
|--------------------------------------------------------------------------
|
| Header untuk semua halaman di area Amil.
|
*/

// Mengambil nama amil dari sesi untuk ditampilkan
$nama_amil_login = $_SESSION['amil_nama_lengkap'] ?? 'Amil';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' - Amil Lazismu' : 'Dashboard Amil'; ?>
    </title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <!-- Custom CSS untuk layout dan tema oranye -->
    <style>
    body {
        background-color: #f8f9fa;
        font-size: .9rem;
    }

    .sidebar {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 100;
        padding: 56px 0 0;
        box-shadow: inset -1px 0 0 rgba(0, 0, 0, .1);
    }

    @media (max-width: 767.98px) {
        .sidebar {
            top: 56px;
        }
    }

    .sidebar-sticky {
        height: calc(100vh - 56px);
        overflow-x: hidden;
        overflow-y: auto;
    }

    .navbar-brand {
        background-color: #fb8c00;
    }

    .bg-orange-custom {
        background-color: #fb8c00 !important;
    }

    /* Tema Oranye untuk Sidebar */
    .sidebar .nav-link {
        color: #343a40;
        transition: background-color 0.2s, color 0.2s;
    }

    .sidebar .nav-link:hover {
        background-color: #fff3e0;
        color: #e65100;
    }

    .sidebar .nav-link.active {
        color: #e65100;
        font-weight: 600;
    }

    .sidebar .nav-link.active i {
        color: #e65100;
    }

    .sidebar-heading {
        color: #fb8c00 !important;
        font-weight: 600;
        text-transform: uppercase;
        font-size: 0.8rem;
    }
    </style>
</head>

<body>

    <header class="navbar navbar-dark sticky-top bg-orange-custom flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-md-3 col-lg-2 me-0 px-3 fs-6" href="#">Area Amil Lazismu</a>
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="navbar-nav">
            <div class="nav-item text-nowrap">
                <a class="nav-link px-3" href="../logout.php">Sign out <i class="bi bi-box-arrow-right"></i></a>
            </div>
        </div>
    </header>