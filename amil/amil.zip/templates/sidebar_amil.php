<?php
/*
|--------------------------------------------------------------------------
| File: amil/templates/sidebar_amil.php
|--------------------------------------------------------------------------
|
| Sidebar untuk semua halaman di area Amil.
|
*/

// Mengambil nama file saat ini untuk menandai menu yang aktif
$current_page = basename($_SERVER['PHP_SELF']);
?>
<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
    <div class="position-sticky pt-3 sidebar-sticky">
        <h6
            class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-1 mb-1 text-muted text-uppercase">
            <span>Utama</span>
        </h6>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>"
                    href="dashboard.php">
                    <i class="bi bi-house-door-fill me-2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'tugas_saya.php') ? 'active' : ''; ?>"
                    href="tugas_saya.php">
                    <i class="bi bi-card-checklist me-2"></i> Tugas Saya
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo in_array($current_page, ['riwayat_pengambilan.php', 'edit_pengambilan.php']) ? 'active' : ''; ?>"
                    href="riwayat_pengambilan.php">
                    <i class="bi bi-clock-history me-2"></i> Riwayat Pengambilan
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'peta_kotak_infak.php') ? 'active' : ''; ?>"
                    href="peta_kotak_infak.php">
                    <i class="bi bi-map-fill me-2"></i> Peta Kotak Infak
                </a>
            </li>
        </ul>

        <!-- === BAGIAN BARU: Menu Kotak Infak === -->
        <h6
            class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span>Kotak Infak</span>
        </h6>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?php echo in_array($current_page, ['kelola_kotak_infaq.php', 'edit_kotak_infaq.php']) ? 'active' : ''; ?>"
                    href="kelola_kotak_infaq.php">
                    <i class="bi bi-collection-fill me-2"></i> Kelola Kotak Infak
                </a>
            </li>
        </ul>
        <!-- === AKHIR BAGIAN BARU === -->

        <h6
            class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span>Konten</span>
        </h6>
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'tambah_berita.php') ? 'active' : ''; ?>"
                    href="tambah_berita.php">
                    <i class="bi bi-pencil-square me-2"></i> Tambah Berita
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo in_array($current_page, ['kelola_berita.php', 'edit_berita.php']) ? 'active' : ''; ?>"
                    href="kelola_berita.php">
                    <i class="bi bi-newspaper me-2"></i> Kelola Berita
                </a>
            </li>
        </ul>

        <h6
            class="sidebar-heading d-flex justify-content-between align-items-center px-3 mt-4 mb-1 text-muted text-uppercase">
            <span>Akun Saya</span>
        </h6>
        <ul class="nav flex-column mb-2">
            <li class="nav-item">
                <a class="nav-link <?php echo ($current_page == 'edit_profil.php') ? 'active' : ''; ?>"
                    href="edit_profil.php">
                    <i class="bi bi-person-circle me-2"></i> Edit Profil
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                </a>
            </li>
        </ul>
    </div>
</nav>
