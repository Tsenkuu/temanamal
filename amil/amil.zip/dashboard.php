<?php
/*
|--------------------------------------------------------------------------
| File: amil/dashboard.php
|--------------------------------------------------------------------------
|
| Halaman utama untuk Amil setelah login.
|
*/
require_once '../includes/config.php';

if (!isset($_SESSION['amil_id'])) {
    header('Location: ../login.php');
    exit();
}
$id_amil_login = $_SESSION['amil_id'];
$page_title = "Dashboard Amil";

// Query untuk statistik
$stmt_pending = $mysqli->prepare("SELECT COUNT(id) AS total FROM tugas_pengambilan WHERE id_amil = ? AND status = 'Ditugaskan'");
$stmt_pending->bind_param("i", $id_amil_login);
$stmt_pending->execute();
$tugas_pending = $stmt_pending->get_result()->fetch_assoc()['total'] ?? 0;
$stmt_pending->close();

$stmt_selesai = $mysqli->prepare("SELECT COUNT(id) AS total FROM tugas_pengambilan WHERE id_amil = ? AND status = 'Selesai'");
$stmt_selesai->bind_param("i", $id_amil_login);
$stmt_selesai->execute();
$tugas_selesai = $stmt_selesai->get_result()->fetch_assoc()['total'] ?? 0;
$stmt_selesai->close();

$stmt_donasi = $mysqli->prepare("SELECT SUM(jumlah_terkumpul) AS total FROM riwayat_pengambilan WHERE id_amil = ?");
$stmt_donasi->bind_param("i", $id_amil_login);
$stmt_donasi->execute();
$total_donasi = $stmt_donasi->get_result()->fetch_assoc()['total'] ?? 0;
$stmt_donasi->close();

require_once 'templates/header_amil.php';
?>
<div class="container-fluid">
    <div class="row">
        <?php require_once 'templates/sidebar_amil.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div
                class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo $page_title; ?></h1>
            </div>
            <div class="alert alert-info">
                Selamat datang kembali, <strong><?php echo htmlspecialchars($nama_amil_login); ?></strong>!
            </div>
            <!-- Kartu Statistik -->
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-warning h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-white-75 small">Tugas Belum Selesai</div>
                                    <div class="text-lg fw-bold"><?php echo $tugas_pending; ?></div>
                                </div>
                                <i class="bi bi-hourglass-split fs-1"></i>
                            </div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="tugas_saya.php">Lihat Detail</a>
                            <div class="small text-white"><i class="bi bi-chevron-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-success h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-white-75 small">Tugas Telah Selesai</div>
                                    <div class="text-lg fw-bold"><?php echo $tugas_selesai; ?></div>
                                </div>
                                <i class="bi bi-check-circle-fill fs-1"></i>
                            </div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="riwayat_pengambilan.php">Lihat Riwayat</a>
                            <div class="small text-white"><i class="bi bi-chevron-right"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card text-white bg-primary h-100">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="text-white-75 small">Total Donasi Terkumpul</div>
                                    <div class="text-lg fw-bold">Rp
                                        <?php echo number_format($total_donasi, 0, ',', '.'); ?></div>
                                </div>
                                <i class="bi bi-wallet2 fs-1"></i>
                            </div>
                        </div>
                        <div class="card-footer d-flex align-items-center justify-content-between">
                            <a class="small text-white stretched-link" href="riwayat_pengambilan.php">Lihat Riwayat</a>
                            <div class="small text-white"><i class="bi bi-chevron-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<?php require_once 'templates/footer_amil.php'; ?>