<?php
require_once '../includes/config.php';

// Pengecekan Login Amil
if (!isset($_SESSION['amil_id'])) {
    header('Location: ../login.php');
    exit();
}

$nama_amil_login = $_SESSION['amil_nama_lengkap'] ?? 'Amil';
$page_title = "Kelola Berita Saya";

// Query untuk mengambil berita yang ditulis oleh amil ini, termasuk statusnya
$stmt = $mysqli->prepare("SELECT id, judul, gambar, status, created_at FROM berita WHERE penulis = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $nama_amil_login);
$stmt->execute();
$result_berita = $stmt->get_result();
$stmt->close();

require_once 'templates/header_amil.php';
?>

<div class="container-fluid">
    <div class="row">
        <?php require_once 'templates/sidebar_amil.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo $page_title; ?></h1>
                <a href="tambah_berita.php" class="btn btn-sm btn-primary">
                    <i class="bi bi-plus-circle me-1"></i> Tulis Berita Baru
                </a>
            </div>

            <?php
            if (isset($_SESSION['success_message'])) {
                echo '<div class="alert alert-success alert-dismissible fade show" role="alert">' . htmlspecialchars($_SESSION['success_message']) . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
                unset($_SESSION['success_message']);
            }
            ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 10%;">Gambar</th>
                                    <th>Judul Berita</th>
                                    <th>Tanggal Kirim</th>
                                    <th class="text-center">Status</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result_berita->num_rows > 0): ?>
                                <?php while($berita = $result_berita->fetch_assoc()): 
                                    // Logika untuk warna badge status
                                    $status_badge_class = 'bg-secondary'; // Default
                                    if ($berita['status'] == 'published') {
                                        $status_badge_class = 'bg-success';
                                    } elseif ($berita['status'] == 'rejected') {
                                        $status_badge_class = 'bg-danger';
                                    } elseif ($berita['status'] == 'pending') {
                                        $status_badge_class = 'bg-warning text-dark';
                                    }
                                ?>
                                <tr>
                                    <td>
                                        <img src="../assets/uploads/berita/<?php echo htmlspecialchars($berita['gambar']); ?>"
                                            alt="<?php echo htmlspecialchars($berita['judul']); ?>"
                                            class="img-fluid rounded" style="width: 100px; height: 60px; object-fit: cover;">
                                    </td>
                                    <td><?php echo htmlspecialchars($berita['judul']); ?></td>
                                    <td><?php echo date('d M Y', strtotime($berita['created_at'])); ?></td>
                                    <td class="text-center">
                                        <span class="badge <?php echo $status_badge_class; ?>">
                                            <?php echo ucfirst($berita['status']); ?>
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <a href="edit_berita.php?id=<?php echo $berita['id']; ?>" class="btn btn-sm btn-warning me-2" title="Edit">
                                            <i class="bi bi-pencil-square"></i>
                                        </a>
                                        <a href="hapus_berita.php?id=<?php echo $berita['id']; ?>" class="btn btn-sm btn-danger" title="Hapus" onclick="return confirm('Apakah Anda yakin ingin menghapus berita ini?');">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                                <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">Anda belum menulis berita apapun.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<?php require_once 'templates/footer_amil.php'; ?>
