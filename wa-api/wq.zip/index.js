/*
|--------------------------------------------------------------------------
| File: apiwa/index.js
|--------------------------------------------------------------------------
|
| Ini adalah file utama yang menjalankan server Node.js untuk bot WhatsApp.
|
*/

require("dotenv").config();
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const express = require("express");
const qrcode = require("qrcode-terminal");
const axios = require("axios");
const cheerio = require("cheerio");
const fs = require("fs"); // Modul File System untuk menghapus folder
const cors = require("cors");

const app = express();
app.use(cors()); // Tambahkan ini untuk mengizinkan semua permintaan CORS
app.use(express.json());

const PORT = process.env.PORT || 3001;
const API_TOKEN = process.env.API_TOKEN;

let sock;
let lastQRCodeBase64 = null; // Simpan QR terakhir
let lastQRCodeTimestamp = null;
let connectionStatus = {
  connected: false,
  qrAvailable: false,
  message: 'Initializing...'
};

async function connectToWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState("auth_info_baileys");

  sock = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: true,
    auth: state,
  });

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update;
    if (qr) {
      console.log("Pindai QR Code ini dengan WhatsApp Anda:");
      qrcode.generate(qr, { small: true });
      generateQRCodeBase64(qr).then((base64) => {
        lastQRCodeBase64 = base64;
        lastQRCodeTimestamp = new Date();
        connectionStatus = { connected: false, qrAvailable: true, message: 'Waiting for QR scan' };
      });
    }
    if (connection === "close") {
      const shouldReconnect =
        lastDisconnect.error?.output?.statusCode !== DisconnectReason.loggedOut;
      connectionStatus = { connected: false, qrAvailable: false, message: `Connection closed. ${shouldReconnect ? 'Reconnecting...' : 'Logged out.'}` };
      console.log(
        "Koneksi terputus, mencoba menghubungkan kembali...",
        shouldReconnect
      );
      if (shouldReconnect) {
        connectToWhatsApp();
      } else {
        // Logged out, clear session
        try {
            if (fs.existsSync("./auth_info_baileys")) {
                fs.rmSync("./auth_info_baileys", { recursive: true, force: true });
            }
        } catch(e) {
            console.error("Gagal menghapus folder auth setelah logout:", e);
        }
      }
    } else if (connection === "open") {
      console.log("Berhasil terhubung ke WhatsApp!");
      lastQRCodeBase64 = null;
      lastQRCodeTimestamp = null;
      connectionStatus = { connected: true, qrAvailable: false, message: 'Connected' };
    }
  });

  sock.ev.on("creds.update", saveCreds);
}

// Fungsi untuk generate QR base64
async function generateQRCodeBase64(qrText) {
  const QRCode = require("qrcode");
  return await QRCode.toDataURL(qrText);
}

// Fungsi untuk memformat nomor telepon
const formatPhoneNumber = (number) => {
  let formatted = number.replace(/\D/g, ""); // Hapus semua karakter non-digit
  if (formatted.startsWith("0")) {
    formatted = "62" + formatted.slice(1);
  } else if (formatted.startsWith("8")) {
    formatted = "62" + formatted;
  }
  return `${formatted}@s.whatsapp.net`;
};

// Middleware untuk validasi token
const validateToken = (req, res, next) => {
    const token = req.body.token || req.query.token;
    if (token !== API_TOKEN) {
        return res.status(401).json({ success: false, message: "Unauthorized" });
    }
    next();
};


// Endpoint API untuk mengirim pesan WhatsApp
app.post("/kirim-pesan", validateToken, async (req, res) => {
  const { nomor, pesan, gambar_url } = req.body;

  if (!nomor || !pesan) {
    return res
      .status(400)
      .json({ success: false, message: "Nomor dan pesan wajib diisi" });
  }

  try {
    const formattedNomor = formatPhoneNumber(nomor);
    const [result] = await sock.onWhatsApp(formattedNomor);

    if (result && result.exists) {
      if (gambar_url) {
        await sock.sendMessage(formattedNomor, {
          image: { url: gambar_url },
          caption: pesan,
        });
      } else {
        await sock.sendMessage(formattedNomor, { text: pesan });
      }
      res
        .status(200)
        .json({ success: true, message: "Pesan berhasil dikirim" });
    } else {
      res
        .status(404)
        .json({ success: false, message: "Nomor tidak terdaftar di WhatsApp" });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Gagal mengirim pesan",
      error: error.message,
    });
  }
});

// Endpoint untuk mereset sesi (logout)
app.post("/reset", validateToken, async (req, res) => {
  console.log("Mereset sesi bot...");
  lastQRCodeBase64 = null;
  lastQRCodeTimestamp = null;
  try {
    await sock.logout();
  } catch (e) {
    console.error("Error during logout, attempting to delete auth folder as fallback.", e);
  }
  
  try {
    fs.rmdirSync("./auth_info_baileys", { recursive: true });
  } catch (e) {
    console.error("Gagal menghapus folder auth:", e);
  }

  res.json({
    success: true,
    message: "Sesi berhasil direset. Menghubungkan kembali untuk mendapatkan QR baru...",
  });
  
  // Reconnect to get a new QR code
  connectToWhatsApp();
});

app.get("/kalkulator-details", async (req, res) => {
  try {
    // PERBAIKAN: Menggunakan URL spesifik untuk Zakat Emas
    const { data } = await axios.get(
      "https://sobatberbagi.com/kalkulator-zakat/emas"
    );
    const $ = cheerio.load(data);

    const parseValue = (selector) => {
      const text = $(selector).text();
      return parseInt(text.replace(/Rp|\.| /g, ""), 10) || 0;
    };

    const hargaEmasPerGram = parseValue(
      "#note-zakat ul li:contains('Harga emas per gram') strong"
    );
    const nisabBulanan = parseValue(
      "#note-zakat ul li:contains('Nishab 85 gram per bulan') strong"
    );
    const nisabTahunan = parseValue(
      "#note-zakat ul li:contains('Nishab 85 gram per tahun') strong"
    );
    const hargaGabahPerKg = parseValue(
      "#note-zakat ul li:contains('Harga gabah per kg') strong"
    );
    const nisabPertanian = parseValue(
      "#note-zakat ul li:contains('Nishab Zakat Pertanian') strong"
    );

    if (!hargaEmasPerGram || !nisabTahunan) {
      throw new Error("Gagal mengambil data nisab utama.");
    }

    res.json({
      success: true,
      data: {
        harga_emas_per_gram: hargaEmasPerGram,
        harga_gabah_per_kg: hargaGabahPerKg,
        nisab_maal_tahunan: nisabTahunan,
        nisab_maal_bulanan: nisabBulanan,
        nisab_pertanian: nisabPertanian,
      },
    });
  } catch (error) {
    console.error("Gagal mengambil detail kalkulator:", error.message);
    // Kirim data default jika scraping gagal
    const hargaEmasDefault = 1889898;
    res.status(500).json({
      success: false,
      message: "Gagal mengambil data, menggunakan nilai default.",
      data: {
        harga_emas_per_gram: hargaEmasDefault,
        harga_gabah_per_kg: 6000,
        nisab_maal_tahunan: 85 * hargaEmasDefault,
        nisab_maal_bulanan: (85 * hargaEmasDefault) / 12,
        nisab_pertanian: 653 * 6000,
      },
    });
  }
});

// Endpoint status
app.get("/status", validateToken, (req, res) => {
  res.json({
    success: true,
    data: connectionStatus
  });
});

// Endpoint untuk ambil QR terakhir
app.get("/qr", validateToken, (req, res) => {
  if (lastQRCodeBase64) {
    res.json({ success: true, data: { qr: lastQRCodeBase64, ts: lastQRCodeTimestamp } });
  } else {
    res.json({ success: false, message: "QR Code tidak tersedia saat ini." });
  }
});

app.listen(PORT, () => {
  console.log(`Server API WhatsApp berjalan di port ${PORT}`);
  connectToWhatsApp();
});
