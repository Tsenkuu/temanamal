<?php
require_once '../includes/config.php';

// Pengecekan login (bisa untuk admin atau amil)
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['amil_id'])) {
    header('Location: ../login.php');
    exit();
}

// Proteksi CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$page_title = "Edit Data Kotak Infak";
$id_kotak = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Menentukan halaman redirect jika terjadi error atau sukses
$redirect_page = isset($_SESSION['admin_id']) ? 'kelola_kotak_infak.php' : '../amil/kelola_kotak_infaq.php';

if ($id_kotak === 0) {
    header("Location: " . $redirect_page);
    exit;
}

// Proses form saat disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($csrf_token, $_POST['csrf_token'])) {
        die('Error: Invalid CSRF token.');
    }

    // Ambil dan bersihkan input
    $kode_kotak = trim($_POST['kode_kotak']);
    $nama_lokasi = trim($_POST['nama_lokasi']);
    $alamat = trim($_POST['alamat']);
    $pic_nama = trim($_POST['pic_nama']);
    $pic_kontak = trim($_POST['pic_kontak']);
    $link_gmaps = trim($_POST['link_gmaps']);
    $tanggal_penempatan = !empty($_POST['tanggal_penempatan']) ? trim($_POST['tanggal_penempatan']) : null;
    $status = $_POST['status'];
    $latitude = !empty($_POST['latitude']) ? trim($_POST['latitude']) : null;
    $longitude = !empty($_POST['longitude']) ? trim($_POST['longitude']) : null;
    
    // Query UPDATE
    $stmt = $mysqli->prepare("UPDATE kotak_infak SET kode_kotak=?, nama_lokasi=?, alamat=?, pic_nama=?, pic_kontak=?, latitude=?, longitude=?, link_gmaps=?, tanggal_penempatan=?, status=? WHERE id=?");
    $stmt->bind_param("ssssssdsssi", $kode_kotak, $nama_lokasi, $alamat, $pic_nama, $pic_kontak, $latitude, $longitude, $link_gmaps, $tanggal_penempatan, $status, $id_kotak);
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Data Kotak Infak berhasil diperbarui.";
        unset($_SESSION['csrf_token']);
        header("Location: " . $redirect_page);
        exit;
    } else {
        $error_message = "Gagal memperbarui data. Error: " . $stmt->error;
    }
    $stmt->close();
}

// Ambil data kotak infak yang akan diedit
$stmt_select = $mysqli->prepare("SELECT * FROM kotak_infak WHERE id = ?");
$stmt_select->bind_param("i", $id_kotak);
$stmt_select->execute();
$result = $stmt_select->get_result();
$kotak = $result->fetch_assoc();
$stmt_select->close();

if (!$kotak) {
    header("Location: " . $redirect_page);
    exit;
}

// Tentukan template berdasarkan peran
if (isset($_SESSION['admin_id'])) {
    $header_file = 'templates/header_admin.php';
    $sidebar_file = 'templates/sidebar_admin.php';
    $footer_file = 'templates/footer_admin.php';
    $cancel_link = 'kelola_kotak_infak.php';
} else { // Amil
    // [PERBAIKAN] Path relatif yang benar untuk Amil
    $header_file = '../amil/templates/header_amil.php';
    $sidebar_file = '../amil/templates/sidebar_amil.php';
    $footer_file = '../amil/templates/footer_amil.php';
    $cancel_link = '../amil/kelola_kotak_infaq.php';
}
require_once $header_file;
?>

<!-- Memuat CSS Leaflet untuk Peta Interaktif -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<style>
    #map-picker { height: 350px; width: 100%; border-radius: 0.5rem; border: 1px solid #ddd; margin-top: 1rem; }
</style>

<div class="container-fluid">
    <div class="row">
        <?php require_once $sidebar_file; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2"><?php echo htmlspecialchars($page_title); ?></h1>
            </div>

            <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <div class="card shadow-sm">
                <div class="card-body">
                    <form action="edit_kotak_infak.php?id=<?php echo $id_kotak; ?>" method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        <input type="hidden" id="latitude" name="latitude" value="<?php echo htmlspecialchars($kotak['latitude']); ?>">
                        <input type="hidden" id="longitude" name="longitude" value="<?php echo htmlspecialchars($kotak['longitude']); ?>">

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="kode_kotak" class="form-label">Kode Kotak</label>
                                <input type="text" class="form-control" id="kode_kotak" name="kode_kotak" value="<?php echo htmlspecialchars($kotak['kode_kotak']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="nama_lokasi" class="form-label">Nama Lokasi</label>
                                <input type="text" class="form-control" id="nama_lokasi" name="nama_lokasi" value="<?php echo htmlspecialchars($kotak['nama_lokasi']); ?>" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="alamat" name="alamat" rows="2"><?php echo htmlspecialchars($kotak['alamat']); ?></textarea>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="pic_nama" class="form-label">Nama PIC</label>
                                <input type="text" class="form-control" id="pic_nama" name="pic_nama" value="<?php echo htmlspecialchars($kotak['pic_nama']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="pic_kontak" class="form-label">Kontak PIC</label>
                                <input type="tel" class="form-control" id="pic_kontak" name="pic_kontak" value="<?php echo htmlspecialchars($kotak['pic_kontak']); ?>">
                            </div>
                        </div>

                        <hr class="my-4">
                        <div class="mb-3">
                            <label class="form-label">Lokasi di Peta</label>
                            <div class="input-group">
                                <button class="btn btn-primary" type="button" id="get-location-btn">
                                    <i class="bi bi-geo-alt-fill me-2"></i> Dapatkan & Perbarui Lokasi
                                </button>
                                <input type="url" class="form-control" id="link_gmaps" name="link_gmaps" value="<?php echo htmlspecialchars($kotak['link_gmaps']); ?>" placeholder="Akan terisi otomatis">
                            </div>
                            <small class="form-text text-muted">Gunakan tombol untuk akurasi, atau seret penanda di peta di bawah ini.</small>
                        </div>
                        <div id="map-picker"></div>
                        
                        <div class="row mt-4">
                            <div class="col-md-6 mb-3">
                                <label for="tanggal_penempatan" class="form-label">Tanggal Penempatan</label>
                                <input type="date" class="form-control" id="tanggal_penempatan" name="tanggal_penempatan" value="<?php echo htmlspecialchars($kotak['tanggal_penempatan']); ?>">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="status" class="form-label">Status</label>
                                <select class="form-select" id="status" name="status" required>
                                    <option value="Aktif" <?php if ($kotak['status'] == 'Aktif') echo 'selected'; ?>>Aktif</option>
                                    <option value="Tidak Aktif" <?php if ($kotak['status'] == 'Tidak Aktif') echo 'selected'; ?>>Tidak Aktif</option>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        <a href="<?php echo $cancel_link; ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Memuat JS Leaflet & Logika Peta -->
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var initialLat = <?php echo !empty($kotak['latitude']) ? $kotak['latitude'] : '-8.0633'; ?>;
    var initialLng = <?php echo !empty($kotak['longitude']) ? $kotak['longitude'] : '111.9008'; ?>;
    var initialZoom = <?php echo !empty($kotak['latitude']) ? '17' : '13'; ?>;

    var map = L.map('map-picker').setView([initialLat, initialLng], initialZoom);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    var marker = null;
    var latInput = document.getElementById('latitude');
    var lngInput = document.getElementById('longitude');
    var gmapsLinkInput = document.getElementById('link_gmaps');
    var getLocationBtn = document.getElementById('get-location-btn');
    var defaultBtnText = getLocationBtn.innerHTML;

    function updateMarker(lat, lng) {
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng], { draggable: true }).addTo(map);
            marker.on('dragend', function(e) {
                var newPos = e.target.getLatLng();
                updateInputs(newPos.lat, newPos.lng);
            });
        }
        map.setView([lat, lng], 17);
        updateInputs(lat, lng);
    }

    function updateInputs(lat, lng) {
        latInput.value = lat.toFixed(8);
        lngInput.value = lng.toFixed(8);
        gmapsLinkInput.value = `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`;
    }
    
    getLocationBtn.addEventListener('click', function() {
        if (!navigator.geolocation) {
            alert('Geolocation tidak didukung oleh browser Anda.');
            return;
        }

        this.disabled = true;
        this.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Mencari...';

        navigator.geolocation.getCurrentPosition(
            function(position) {
                updateMarker(position.coords.latitude, position.coords.longitude);
                getLocationBtn.disabled = false;
                getLocationBtn.innerHTML = defaultBtnText;
            },
            function() {
                alert('Tidak dapat mengambil lokasi Anda. Pastikan Anda memberikan izin lokasi.');
                getLocationBtn.disabled = false;
                getLocationBtn.innerHTML = defaultBtnText;
            },
            { enableHighAccuracy: true }
        );
    });

    // Tampilkan marker di posisi awal jika data sudah ada
    if (initialLat !== -8.0633) {
        updateMarker(initialLat, initialLng);
    }
});
</script>

<?php 
require_once $footer_file; 
?>

