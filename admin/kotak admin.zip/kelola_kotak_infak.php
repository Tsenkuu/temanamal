<?php
require_once '../includes/config.php';

// Pengecekan login admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit();
}

$page_title = "Kelola Kotak Infak";
require_once 'templates/header_admin.php';

// --- PEMROSESAN DATA DI AWAL ---

// 1. Ambil semua data kotak infak
$result = $mysqli->query("SELECT * FROM kotak_infak ORDER BY nama_lokasi ASC");

// 2. Inisialisasi variabel
$kotak_infak_list = [];
$locations_for_map = []; // Array khusus untuk data peta
$total_count = 0;
$active_count = 0;

// 3. Proses data sekali jalan untuk efisiensi
if ($result && $result->num_rows > 0) {
    $total_count = $result->num_rows;
    while ($row = $result->fetch_assoc()) {
        $kotak_infak_list[] = $row; // Data lengkap untuk tabel
        if ($row['status'] == 'Aktif') {
            $active_count++;
            if (!empty($row['latitude']) && !empty($row['longitude'])) {
                $locations_for_map[] = [
                    'nama_lokasi' => $row['nama_lokasi'],
                    'alamat' => $row['alamat'],
                    'pic_nama' => $row['pic_nama'],
                    'lat' => $row['latitude'],
                    'lng' => $row['longitude']
                ];
            }
        }
    }
}
$inactive_count = $total_count - $active_count;

function get_status_badge($status) {
    $badge_class = ($status == 'Aktif') ? 'bg-success' : 'bg-secondary';
    $icon = ($status == 'Aktif') ? 'bi-check-circle' : 'bi-x-circle';
    return "<span class=\"badge {$badge_class} px-2 py-1 rounded-pill\"><i class=\"bi {$icon} me-1\"></i>{$status}</span>";
}
?>

<!-- Memuat CSS untuk Peta Leaflet -->
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
<style>
    .main-content { background-color: #f8f9fa; }
    .card { transition: transform 0.2s, box-shadow 0.2s; }
    .card:hover { transform: translateY(-2px); box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1) !important; }
    .kotak-item:hover { background-color: #f8f9fa; }
    .kotak-icon { width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; }
    .table th { font-weight: 600; font-size: 0.85rem; text-transform: uppercase; color: #6c757d; }
    #map-view { height: 450px; border-radius: 0.5rem; }
</style>

<div class="container-fluid">
    <div class="row">
        <?php require_once 'templates/sidebar_admin.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <div>
                    <h1 class="h3 fw-semibold text-dark"><?php echo htmlspecialchars($page_title); ?></h1>
                    <p class="text-muted">Kelola semua kotak infak yang terdaftar dalam sistem.</p>
                </div>
                <a href="tambah_kotak_infak.php" class="btn btn-primary rounded-pill px-3 py-2 shadow-sm">
                    <i class="bi bi-plus-circle me-1"></i> Tambah Kotak Baru
                </a>
            </div>

            <?php if (isset($_SESSION['success_message'])) : ?>
            <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
                <i class="bi bi-check-circle-fill me-2"></i>
                <div><?php echo htmlspecialchars($_SESSION['success_message']); ?></div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
            <?php unset($_SESSION['success_message']); endif; ?>

            <div class="row">
                <div class="col-lg-8">
                    <!-- Daftar Kotak Infak -->
                    <div class="card shadow-sm border-0 rounded-3 mb-4">
                        <div class="card-header bg-white py-3 border-0 d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0 fw-semibold">Daftar Kotak Infak</h5>
                            <div class="w-50">
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                                    <input type="text" class="form-control border-0 bg-light" id="searchInput" placeholder="Cari (Kode, Lokasi, PIC)...">
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th class="ps-4">Kode Kotak</th>
                                            <th>Nama Lokasi</th>
                                            <th>Nama PIC</th>
                                            <th class="text-center">Status</th>
                                            <th class="text-center pe-4">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody id="kotakTableBody">
                                        <?php if (!empty($kotak_infak_list)) : foreach ($kotak_infak_list as $row) : ?>
                                        <tr class="kotak-item" data-searchable-text="<?php echo strtolower(htmlspecialchars($row['kode_kotak'] . ' ' . $row['nama_lokasi'] . ' ' . $row['pic_nama'])); ?>">
                                            <td class="ps-4">
                                                <div class="d-flex align-items-center">
                                                    <div class="kotak-icon bg-primary text-white rounded-circle me-3"><i class="bi bi-box-seam"></i></div>
                                                    <strong><?php echo htmlspecialchars($row['kode_kotak']); ?></strong>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($row['nama_lokasi']); ?></td>
                                            <td><?php echo htmlspecialchars($row['pic_nama']); ?></td>
                                            <td class="text-center"><?php echo get_status_badge($row['status']); ?></td>
                                            <td class="text-center pe-4">
                                                <div class="btn-group">
                                                    <a href="edit_kotak_infak.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-secondary rounded-pill me-1" title="Edit"><i class="bi bi-pencil"></i> Edit</a>
                                                    <button type="button" class="btn btn-sm btn-outline-info rounded-pill detail-btn" data-id="<?php echo $row['id']; ?>" title="Detail"><i class="bi bi-info-circle"></i></button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; else : ?>
                                        <tr><td colspan="5" class="text-center text-muted py-5"><i class="bi bi-inbox display-4 d-block mb-2"></i>Belum ada data.</td></tr>
                                        <?php endif; ?>
                                        <tr id="noResultsRow" style="display: none;"><td colspan="5" class="text-center text-muted py-5"><i class="bi bi-search display-4 d-block mb-2"></i>Data tidak ditemukan.</td></tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <!-- Statistik -->
                    <div class="card shadow-sm border-0 rounded-3 mb-4">
                        <div class="card-header bg-white py-3 border-0"><h5 class="card-title mb-0 fw-semibold">Statistik</h5></div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3 p-3 bg-light rounded-3">
                                <div><h6 class="mb-0 text-muted">Total Kotak</h6><h3 class="mb-0 fw-bold"><?php echo $total_count; ?></h3></div>
                                <div class="bg-primary text-white p-3 rounded-circle"><i class="bi bi-box-seam fs-4"></i></div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center p-3 bg-light rounded-3">
                                <div><h6 class="mb-0 text-muted">Kotak Aktif</h6><h3 class="mb-0 fw-bold text-success"><?php echo $active_count; ?></h3></div>
                                <div class="bg-success text-white p-3 rounded-circle"><i class="bi bi-check-circle fs-4"></i></div>
                            </div>
                        </div>
                    </div>
                    <!-- Peta -->
                    <div class="card shadow-sm border-0 rounded-3">
                        <div class="card-header bg-white py-3 border-0"><h5 class="card-title mb-0 fw-semibold">Peta Sebaran</h5></div>
                        <div class="card-body"><div id="map-view" class="shadow-sm"></div></div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>

<!-- Modal Detail -->
<div class="modal fade" id="detailModal" tabindex="-1"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-3">
    <div class="modal-header"><h5 class="modal-title">Detail Kotak Infak</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
    <div class="modal-body" id="modalBodyContent"></div>
    <div class="modal-footer"><button type="button" class="btn btn-secondary rounded-pill" data-bs-dismiss="modal">Tutup</button><a href="#" id="editLink" class="btn btn-primary rounded-pill">Edit Data</a></div>
</div></div></div>

<?php require_once 'templates/footer_admin.php'; ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var locations = <?php echo json_encode($locations_for_map); ?>;
    var map = L.map('map-view').setView([-8.0633, 111.9008], 12);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap' }).addTo(map);
    var markers = L.layerGroup().addTo(map);
    locations.forEach(loc => L.marker([loc.lat, loc.lng]).addTo(markers).bindPopup(`<b>${loc.nama_lokasi}</b><br><small>PIC: ${loc.pic_nama}</small>`));
    if (locations.length > 0) map.fitBounds(markers.getBounds(), { padding: [20, 20] });

    const searchInput = document.getElementById('searchInput');
    const tableBody = document.getElementById('kotakTableBody');
    const rows = tableBody.getElementsByClassName('kotak-item');
    const noResultsRow = document.getElementById('noResultsRow');

    searchInput.addEventListener('keyup', () => {
        const filter = searchInput.value.toLowerCase();
        let visibleRows = 0;
        Array.from(rows).forEach(row => {
            const searchableText = row.dataset.searchableText;
            if (searchableText.includes(filter)) {
                row.style.display = '';
                visibleRows++;
            } else {
                row.style.display = 'none';
            }
        });
        noResultsRow.style.display = (visibleRows === 0) ? '' : 'none';
    });

    tableBody.addEventListener('click', e => {
        const target = e.target.closest('.detail-btn');
        if (!target) return;
        const id = target.dataset.id;
        const modalBody = document.getElementById('modalBodyContent');
        const editLink = document.getElementById('editLink');
        const detailModal = new bootstrap.Modal(document.getElementById('detailModal'));
        modalBody.innerHTML = `<div class="text-center py-4"><div class="spinner-border text-primary"></div><p class="mt-2">Memuat data...</p></div>`;
        detailModal.show();
        fetch(`get_kotak_detail.php?id=${id}`)
            .then(res => res.ok ? res.text() : Promise.reject('Gagal mengambil data'))
            .then(html => {
                modalBody.innerHTML = html;
                editLink.href = `edit_kotak_infak.php?id=${id}`;
            })
            .catch(err => {
                modalBody.innerHTML = `<div class="alert alert-danger">Gagal memuat data.</div>`;
                console.error(err);
            });
    });
});
</script>
