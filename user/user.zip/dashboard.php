<?php
// Memuat file konfigurasi, yang seharusnya sudah memanggil session_start()
require_once '../includes/config.php';

// Pengecekan login user, jika tidak ada, arahkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$page_title = "Dashboard Donatur";
$user_id = $_SESSION['user_id'];
$user_nama = $_SESSION['user_nama_lengkap'] ?? 'Donatur';

// 1. Ambil data email dan no_telepon dari user yang login
$stmt_user = $mysqli->prepare("SELECT email, no_telepon FROM user WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user_data = $result_user->fetch_assoc();
$stmt_user->close();

// 2. Ambil riwayat donasi berdasarkan email ATAU no_telepon user
// Ini untuk memastikan semua donasi tercatat, bahkan jika user berdonasi tanpa login
// selama menggunakan email atau nomor HP yang sama.
$sql_donasi = "SELECT d.created_at, d.nominal, d.status, p.nama_program 
               FROM donasi d 
               LEFT JOIN program p ON d.id_program = p.id 
               WHERE d.kontak_donatur = ? OR d.kontak_donatur = ?
               ORDER BY d.created_at DESC";
$stmt_donasi = $mysqli->prepare($sql_donasi);
$stmt_donasi->bind_param("ss", $user_data['email'], $user_data['no_telepon']);
$stmt_donasi->execute();
$result_donasi = $stmt_donasi->get_result();

// Memuat header publik
require_once '../includes/templates/header.php';
?>

<!-- Konten Dasbor User -->
<section class="py-16 px-4 md:px-12 bg-light-bg">
    <div class="container mx-auto max-w-4xl">

        <!-- Sapaan Selamat Datang -->
        <div class="bg-white p-8 rounded-2xl shadow-lg mb-8 scroll-animate">
            <h1 class="text-3xl font-bold text-dark-text">Dasbor Saya</h1>
            <p class="text-gray-600 mt-2">Selamat datang kembali, <span
                    class="font-semibold text-primary-orange"><?php echo htmlspecialchars($user_nama); ?></span>!</p>
            <p class="text-gray-500">Di sini Anda dapat melihat riwayat donasi dan mengelola akun Anda.</p>

            <!-- Tombol Aksi -->
            <div class="mt-6 border-t pt-6 flex flex-col sm:flex-row gap-4">
                <a href="edit_profil.php"
                    class="w-full sm:w-auto text-center bg-gray-200 text-dark-text px-6 py-3 rounded-full font-bold hover:bg-gray-300 transition duration-300">
                    Edit Profil
                </a>
                <a href="ganti_sandi.php"
                    class="w-full sm:w-auto text-center bg-gray-200 text-dark-text px-6 py-3 rounded-full font-bold hover:bg-gray-300 transition duration-300">
                    Ganti Kata Sandi
                </a>
            </div>
        </div>

        <!-- Riwayat Donasi -->
        <div class="bg-white p-8 rounded-2xl shadow-lg scroll-animate">
            <h3 class="text-2xl font-bold text-dark-text mb-6">Riwayat Donasi Anda</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="p-4 font-semibold">Tanggal</th>
                            <th class="p-4 font-semibold">Program</th>
                            <th class="p-4 font-semibold text-right">Nominal (Rp)</th>
                            <th class="p-4 font-semibold text-center">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result_donasi && $result_donasi->num_rows > 0): ?>
                        <?php while($donasi = $result_donasi->fetch_assoc()): ?>
                        <tr class="border-b">
                            <td class="p-4"><?php echo date('d F Y', strtotime($donasi['created_at'])); ?></td>
                            <td class="p-4"><?php echo htmlspecialchars($donasi['nama_program'] ?: 'Donasi Umum'); ?>
                            </td>
                            <td class="p-4 text-right font-medium">
                                <?php echo number_format($donasi['nominal'], 0, ',', '.'); ?></td>
                            <td class="p-4 text-center">
                                <?php
                                                $status = $donasi['status'];
                                                $badge_class = 'bg-gray-400';
                                                if ($status == 'Selesai') $badge_class = 'bg-green-500';
                                                elseif ($status == 'Menunggu Pembayaran' || $status == 'Menunggu Konfirmasi') $badge_class = 'bg-yellow-500';
                                                elseif ($status == 'Dibatalkan') $badge_class = 'bg-red-500';
                                            ?>
                                <span
                                    class="px-3 py-1 text-xs text-white font-semibold rounded-full <?php echo $badge_class; ?>">
                                    <?php echo htmlspecialchars($status); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                        <?php else: ?>
                        <tr>
                            <td colspan="4" class="text-center text-gray-500 py-8">Anda belum memiliki riwayat donasi.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</section>

<?php
// Memuat footer publik
require_once '../includes/templates/footer.php';
?>